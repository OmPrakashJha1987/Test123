/*global QUnit*/

sap.ui.define([
	"com/jumbo/scm/maintaincharge/controller/Maintaincharge.controller"
], function (Controller) {
	"use strict";

	QUnit.module("maintaincharge Controller");

	QUnit.test("I should test the maintaincharge controller", function (assert) {
		var oAppController = new Controller();
		oAppController.onInit();
		assert.ok(oAppController);
	});

});
