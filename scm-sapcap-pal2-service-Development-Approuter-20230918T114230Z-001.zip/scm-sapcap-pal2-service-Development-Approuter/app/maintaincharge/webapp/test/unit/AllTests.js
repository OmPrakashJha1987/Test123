sap.ui.define([
	"com/jumbo/scm/maintaincharge/test/unit/controller/Maintain.controller"
], function () {
	"use strict";
});
